<?php


namespace Nextend\Framework\Controller\Admin;


use Nextend\Framework\Controller\AjaxController;

class AdminAjaxController extends AjaxController {

}